/**
 * Rashedul Khan
 * 108921821
 * CSE 214 (2)
 * TA: Rathish Das
 */


public interface BinaryTree<E> {
	void add(E element);
	void remove(E element);
	boolean contains(E element);
	E min();
	E max();
}
